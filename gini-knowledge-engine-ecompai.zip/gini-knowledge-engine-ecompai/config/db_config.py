# config/db_config.py

DB_CONFIG = {
    'host': 'axonai-alertdb.cnu22gas0okd.us-east-1.rds.amazonaws.com',
    'database': 'axonai_demo',
    'user': 'admin',
    'password': 'ZuPNSn.DO2eD}6Qp|?pwXU%Sud:m'
}
